=== Wysija Newsletters ===
Contributors: wysija
Tags: newsletter, newsletters, manager newsletter, newsletter signup, newsletter widget, subscribers, post notification, email subscription, email alerts, automatic newsletter, auto newsletter, autoresponder, autoresponders, follow up, email marketing, email, emailing, subscription
Requires at least: 3.0
Tested up to: 3.5
Stable tag: trunk

Send your posts and newsletters from WordPress easily, and beautifully.


== Description ==

Drag and drop your articles, images, social bookmarks and dividers in your newsletter. Pick one of 30 themes. Change fonts and colors on the fly. Manage your lists and subscription forms with a few clicks. Configuration is dummy proof. And if you're lost, [we're here](http://support.wysija.com/) to help. Sending newsletters from WordPress is finally fun.


= One minute video demo =

http://vimeo.com/35054446


== Translation Credits ==

Translation to fr_FR by FxB*

Language: French
Translator Name: Fx Bénard
Translator Website: http://www.fxbenard.com
Translator E-mail: fxb@fxbenard.com

* Based on previous collaboration of some contributors, according to the oficial website:
- Kim


== Installation Instructions ==

Place the enclosed files in the plugin folder respecting the file structure as shown below.

/languages/
	wysija-newsletters-fr_FR.mo
	wysija-newsletters-fr_FR.po


== Disclaimer ==

The files provided on this folder and on enclosed folders (Software) are provided "as is". Use at your own risk.